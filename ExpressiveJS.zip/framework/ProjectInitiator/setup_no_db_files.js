const fs = require('fs').promises;
const color = require('../colorCode/ANSI');
const path = require('path');

const files = [
    ['rawUUID.txt', 'applications/UUID-generator.js'],
    ['raw_no_db_App.txt', 'App.js'],
    ['raw_DotENV.txt', '.env'],
    ['raw_GitIgnore.txt', '.gitignore'],
    ['rawREADME.txt', 'README.md'],
    ['raw-cors.txt', 'middlewares/cors.js'],
    ['rawAPI_AUTH.txt', 'middlewares/API_Auth.js'],
    ['rawLimiter.txt', 'middlewares/express-rate-limit.js'],
    ['rawTokenGenerator.txt', 'applications/token-generator.js'],
    ['rawLoggers.txt', 'applications/loggers.js'],
    ['rawHeaderChecker.txt', 'middlewares/headers.js'],
    ['rawRegex.txt', 'applications/regex.js'],
    ['raw_NODEMON.txt', 'nodemon.json'],
    ['rawProxyGuard.txt','middlewares/proxyGuard.js'],
    ['raw-request-event-hamdler.txt', 'middlewares/request-event-hamdler.js'],
    ['rawSignatureGenerator.txt', 'applications/signatureGenerator.js'],
    ['rawScheduler.txt', 'applications/server-workers/scheduler.js'],
    ['rawRegisterWorker.txt', 'applications/server-workers/registerWorker.js'],
    ['rawMailSender.txt', 'applications/mailSender.js'],
    ['raw-session-config.txt','sessions/sessions.config.js'],
    ['rawUploader.txt', 'middlewares/uploader.js'],
    ['rawCloudinaryupload.txt', 'applications/cloudinaryUpload.js'],
    ['rawViewsGitIgnore.txt', 'views/.gitignore'],
    ['rawIndex.txt', 'views/index.html'],
    ['rawViewsTxt.txt', 'views/views.txt'],
    ['raw-integrative-ai-index.txt', 'applications/integrative-ai/index.js'],
    ['raw-integrative-ai-package-json.txt','applications/integrative-ai/package.json'],
    ['raw-integrative-ai-core-package.txt', 'applications/integrative-ai/main/package.json'],
    ['raw-integrative-ai-core-module.txt', 'applications/integrative-ai/main/core.js'],
    ['raw-integrative-ai-tools.txt', 'applications/integrative-ai/tools/index.js'],
];


const create_No_DB_setup_files = async () => {
    const projectRoot = path.join(__dirname, '..', '..');

    for (const [template, respective_Directory] of files) {
        const template_file = path.join(__dirname, 'templates', template);
        const directory = path.join(projectRoot, respective_Directory);

        try {
            const content = await fs.readFile(template_file, 'utf8');
            await fs.writeFile(directory, content);   
        }
        catch (error) {
            console.error(`${color.red}[X]------- Failed to create ${directory}: ${error.message}${color.default_color}`);
        }
    }
};

module.exports = create_No_DB_setup_files;