## This is My README

This is my readme file, I put here what's my application all about.

## About ExpressiveJS

ExpressiveJS is a backend framework that follows MVC pattern and simplifying in creating backend application.
Built on top of ExpressJS, this is basically an upgraded version of the framework, but everything is modularized - from routes, controllers and etc.

If you encounter any bugs, please don't hesitate to reach out to the developer

Having fun building :)