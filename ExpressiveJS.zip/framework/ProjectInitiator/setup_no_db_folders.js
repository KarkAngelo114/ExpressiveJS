const fs = require('fs').promises;
const color = require('../colorCode/ANSI');
const path = require('path');

const create_No_DB_setup_Folders = async () => {
    const folders = [
        'applications/integrative-ai/main',
        'applications/integrative-ai/tools',
        'applications/server-workers',
        'controllers',
        'middlewares',
        'routes',
        'sessions',
        'uploads',
        'views',
    ];

    try {
        for (let i = 0; i < folders.length; i++) {
            const project_folders = path.join(__dirname, '..', '..',  folders[i]);
            await fs.mkdir(project_folders, {recursive:true});
        }
    }
    catch (error) {
        console.error(`${color.red}[X]------- Failed to initiate setup: ${error.message}${color.default_color}`);
        return;
    } 
};

module.exports = create_No_DB_setup_Folders;