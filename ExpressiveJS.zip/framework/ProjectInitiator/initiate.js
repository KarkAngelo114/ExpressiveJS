const { createFolders } = require('./createFolders');
const { createFiles } = require('./fileCreator');
const create_No_DB_setup_Folders = require('./setup_no_db_folders');
const create_No_DB_setup_files = require('./setup_no_db_files');
const { install, setup_no_db_dependencies } = require('../subprocess/dependencyInstaller');
const { configure, no_db_Appconfigure } = require('./config');
const color_code = require('../colorCode/ANSI');
const fs = require('fs').promises;
const path = require('path');
const config = require('./config.json');


/**
 * 
 * once init() is executed, the project will setup as a full fledge backend server application
 * 
 * 
 */
const init = async (value) => {
    const json = path.join(__dirname, 'config.json');
    const content = await fs.readFile(json, 'utf8');
    const config = JSON.parse(content);

    let is_configure = config['has_Setup'];

    if (!is_configure) {
        console.log(`\n${color_code.yellow}============${color_code.default_color} ExpressiveJS Setup ${color_code.yellow}============${color_code.default_color}\n`);
        console.log("\n[TASK]-------Please wait while we set up...");

        await delay(2000);
        console.log("\n[TASK]-------Generating files...");
        createFolders();

        await delay(2000);
        createFiles(value);

        await delay(2000);
        console.log("\n[TASK]-------Installing dependencies...");

        try {
            await install();
            console.log("\n[TASK]-------Setting Database...");
            const { onCreate } = require('../../database/MySQL/createDatabase');
            await onCreate();
            

        } catch (err) {
            console.error(`${color_code.red}[X] Error during setup: ${err.message}${color_code.default_color}`);
        }

        await delay(2000);
        console.log("\n[TASK]-------Finalizing...");
        configure();

        await delay(1000);
        console.log(`\n${color_code.green}[SUCCESS]-----ExpressiveJS setup completed successfully!${color_code.default_color}\n`);
        console.log(`${color_code.yellow} -- Type "node expressiveCLI --help" for more commands.${color_code.default_color}\n`);
        console.log("- - - Thank you for using ExpressiveJS! - - -\n");
    }
    else {
        console.log(`\n${color_code.yellow}[INFO]-------Project already setup${color_code.default_color}`);
    }
    
    
};

/**
 * 
 * this function will initiate a no database server application.
 * 
 */

const no_db_setup = async () => {
    const json = path.join(__dirname, 'config.json');
    const content = await fs.readFile(json, 'utf8');
    const config = JSON.parse(content);

    let is_configure = config['has_Setup'];

    if (!is_configure) {
        console.log(`\n${color_code.yellow}============${color_code.default_color} ExpressiveJS Setup (no database) ${color_code.yellow}============${color_code.default_color}\n`);
        console.log("\n[TASK]-------Please wait while we set up...");

        await delay(2000);
        console.log("\n[TASK]-------Generating files...");
        create_No_DB_setup_Folders();

        await delay(2000);
        create_No_DB_setup_files();

        await delay(2000);
        console.log("\n\n[TASK]-------Installing dependencies...");

        try {
            await delay(2000);
            await setup_no_db_dependencies();
        }
        catch (err) {
            console.error(`${color_code.red}[X] Error during setup: ${err.message}${color_code.default_color}`);
        }

        await delay(2000);
        console.log("\n[TASK]-------Finalizing...");
        no_db_Appconfigure();

        await delay(1000);
        console.log(`${color_code.green}\n[SUCCESS]-----ExpressiveJS setup completed successfully!${color_code.default_color}\n`);
        console.log(`${color_code.yellow} -- Type "node expressiveCLI --help" for more commands.${color_code.default_color}\n`);
        console.log("- - - Thank you for using ExpressiveJS! - - -\n");
    }
    else {
        console.log(`\n${color_code.yellow}[INFO]-------Project already setup${color_code.default_color}`);
    }
}

const initiateUpdate = async () => {
    if (!config['has_Setup']) {
        console.log(`${color_code.yellow}[INFO]------- Project not yet setup${color_code.default_color}`);
        return;
    }

    console.log(`\n${color_code.yellow}============${color_code.default_color} ExpressiveJS Setup ${color_code.yellow}============${color_code.default_color}\n`);
    console.log("[TASK]------- Checking for an update");

    const current_ver = config['version'];
    
};

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

module.exports = {
    init,
    no_db_setup,
    initiateUpdate
};
