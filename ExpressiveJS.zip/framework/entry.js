// frameworks/entry.js

const color = require('./colorCode/ANSI');
const config = require('./ProjectInitiator/config.json');

const createMigrationFile = require('./migrationGenerator/migrationFileGenerator');
const { generateControllerFile, no_db_controller } = require('./controllerGenerator/controllerGenerator');
const createModel = require('./modelGenerator/modelFileGenerator');
const generateRouteFile = require('./routerGenerator/routeFileGenerator');
const generateWorker = require('./workerGenerator/generateWorker');

const { init, no_db_setup, initiateUpdate } = require('./ProjectInitiator/initiate');
const { resetConfig } = require('./ProjectInitiator/config');
const { serve } = require('./serve_app/serveJS');

function runCLI(args) {
    const arg1 = args[0];
    const arg2 = args[1];
    const arg3 = args[2];

    const commandsName = {
        "generate-migration <name>": "Generate a migration file",
        "generate-model <name>": "Generate a model file",
        "generate-controller <name>": "Generate a controller file",
        "generate-route <name>": "Generate a route file",
        "generate-worker <name>": "Generate a worker file",
        "initiate-setup": "Initialize project",
        "initiate-setup --no-db": "Setup project without DB",
        "initiate-setup --setDatabase <db>": "Setup with specific DB (e.g. postgre)",
        "--serve": "Start the app",
        "new": "Reset configuration",
        "--help": "Show available commands"
    };

    if (arg1 === "--help") {
        console.log(`\n${color.yellow}============ expressiveCLI commands ============${color.default_color}\n`);
        for (const cmd in commandsName) {
            console.log(`${color.yellow}${cmd}${color.default_color} - ${commandsName[cmd]}`);
        }
        return;
    }

    switch (arg1) {
        case "generate-model":
            if (!config['has-db']) {
                console.log(`${color.yellow}[INFO]------- Cannot create a model file.${color.default_color}`);
                return;
            }
            return createModel(arg2);

        case "generate-migration":
            if (!config['has-db']) {
                console.log(`${color.yellow}[INFO]------- Cannot create a migration file.${color.default_color}`);
                return;
            }

            return createMigrationFile(arg2);

        case "generate-controller":

            config['has-db'] ? generateControllerFile(arg2) : no_db_controller(arg2);
            return;

        case "generate-route":
            return generateRouteFile(arg2);

        case "generate-worker":
            return generateWorker(arg2);

        case "initiate-setup":
            if (arg2 === "--no-db") {
                return no_db_setup();
            }

            if (arg2 === "--setDatabase") {
                if (!arg3) {
                    return console.log(`${color.red}[X] No database specified.${color.default_color}`);
                }
                return init(arg3);
            }

            return init();

        case "--serve":
            return serve();

        case "new":
            return resetConfig();

        case "update":
            return initiateUpdate();

        default:
            console.log(`${color.yellow}[!] Unknown command "${arg1}".${color.default_color}`);
            console.log(`${color.yellow}[!] Type "expressivecli --help" for available commands.${color.default_color}`);
    }
}

module.exports = { runCLI };