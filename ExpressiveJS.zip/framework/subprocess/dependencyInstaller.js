const { spawn } = require('child_process');
const color_code = require('../colorCode/ANSI');
const config = require('../ProjectInitiator/config.json');

function installDependencies(deps, isDev = false) {
    return new Promise((resolve, reject) => {
        if (!Array.isArray(deps)) {
            return reject(new Error('Dependencies must be an array'));
        }

        const args = ['install', ...deps];
        if (isDev) args.push('--save-dev');

        const child = spawn('npm', args, { stdio: 'inherit', shell:true });

        child.on('close', (code) => {
            if (code !== 0) {
                console.error(`${color_code.red}[ERROR] Install failed${color_code.default_color}`);
                reject(new Error(`Exit code ${code}`));
            } else {
                console.log(`${color_code.green}[SUCCESS] Install complete${color_code.default_color}`);
                resolve();
            }
        });
    });
}

const install = async () => {
    try {
        await installDependencies(config.deps);
        await installDependencies(['nodemon'], true);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
};

const setup_no_db_dependencies = async () => {
    try {
        await installDependencies(config['no-db-deps']);
        await installDependencies(['nodemon'], true);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
};

module.exports = {
    install,
    setup_no_db_dependencies
};