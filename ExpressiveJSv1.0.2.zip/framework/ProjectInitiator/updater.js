
/**
 * 
 * @param {String} flag - if --force flag is set, force update modules that are in the metadata 
 * @returns 
 */
exports.initiateUpdate = async (flag) => {
    try {
        // this will be use for fetching raw source files
        let baseURL = "https://raw.githubusercontent.com/KarkAngelo114/ExpressiveJS/main/src";
        let templates_dir = path.join(__dirname, "..", "ProjectInitiator", "templates");

        if (!config['has_Setup']) {
            console.log(`${color_code.yellow}[INFO]------- Project not yet setup${color_code.default_color}`);
            return;
        }

        console.log(`\n${color_code.yellow}============${color_code.default_color} ExpressiveJS Setup ${color_code.yellow}============${color_code.default_color}\n`);
        console.log("[TASK]------- Checking for an update");

        const current_ver = config['version'];

        console.log(`${color_code.gray}[GET] https://raw.githubusercontent.com/KarkAngelo114/ExpressiveJS/main/metadata.json${color_code.default_color}`);
        console.log(`${color_code.gray}[GET] https://raw.githubusercontent.com/KarkAngelo114/ExpressiveJS/main/CHANGELOG.md${color_code.default_color}\n`);
        const response = await fetch('https://raw.githubusercontent.com/KarkAngelo114/ExpressiveJS/main/metadata.json');
        const change_log_get= await fetch('https://raw.githubusercontent.com/KarkAngelo114/ExpressiveJS/main/CHANGELOG.md');
        
        const data = await response.json();

        const cl = await change_log_get.text();

        if (!response.ok) {
            throw new Error(`${color_code.red}[FAILED]------- Failed to fetch update${color_code.default_color}`);
        }

        if (current_ver !== data.version) {
            console.log(`Current version: ${color_code.yellow}${current_ver}${color_code.default_color}`);
            console.log(`Updated version: ${color_code.green}${data.version}${color_code.default_color}`);
            console.log("\nChange Log:");
            console.log(cl);
        }
        else {
            console.log(`\n${color_code.green}Already up to date ${color_code.default_color}`);
            return;
        }
        
        console.log("\n[TASK]------- Preparing for update");

        console.log('\nFiles to update:');

        for (let i = 0; i < data.files.length; i++) {
            /**  metadata is structured as:
                {
                    files: [
                        *source file from github*
                    ]
                }
            */
            console.log(`- ${data.files[i]}`);
        }

        // First step: update internal .txt templates so that when spinning up a new project, it will use the updated templates
        console.log('\nUpdating internal local templates...');

        console.log('Pulling file contents from the repository...');
        for (const file of data.files) {
            process.stdout.write('\r'+`${color_code.gray}[GET] ${baseURL}/${file}${color_code.default_color}`);

            const response = await fetch(`${baseURL}/${file}`);

            if (response.status == 404) throw new Error(`Source file not found. File might have been moved, deleted or not existing at all.`);

            const content = await response.text();

            await delay(1000);
            // overwrite contents to the local internal template copy
            const final_file_path = path.join(`${templates_dir}`,`${file}`);
            await fs.writeFile(`${final_file_path}`, content);
        }

        

        console.log(`\n\n${color_code.green}[SUCCESS]------- Update finished${color_code.default_color}`);
        console.log(`${color_code.yellow}${current_ver} -> ${color_code.green}${data.version}${color_code.default_color}\n`);

        // update config.json
        await updateVersion(data.version);
    }
    catch (error) {
        console.log(`\n\n${color_code.red}-- Error fetching --${color_code.default_color}\nReason:`);
        console.error(error);
        process.exit(1);
    }
};

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));