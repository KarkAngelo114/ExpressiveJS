const red = '\x1b[31m';
const green = '\x1b[32m';
const default_color = '\x1b[0m';
const yellow = '\x1b[33m';
const gray = "\x1b[90m";

module.exports = {
    red,
    green,
    default_color,
    yellow,
    gray
}